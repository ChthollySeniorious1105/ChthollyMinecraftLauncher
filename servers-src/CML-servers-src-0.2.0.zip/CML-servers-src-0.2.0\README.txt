﻿CML 服务端源码（CMLS / Aurora / Pulse）

  server\                 CMLS 联机中继（Java TCP + 基岩版 UDP），依赖 core\
  modules\aurora\server\  Aurora 小游戏服务端，依赖 modules\aurora\shared\
  modules\pulse\server\   Pulse 语音聊天服务端，依赖 modules\pulse\shared\

构建（需要 Dart 3.9+ 或 Flutter 自带的 dart）：
  cd server;                dart pub get; dart compile exe bin\cmls.dart -o cmls.exe
  cd modules\aurora\server; dart pub get; dart compile exe bin\aurora_server.dart -o aurora_server.exe
  cd modules\pulse\server;  dart pub get; dart compile exe bin\pulse_server.dart -o pulse_server.exe
或直接运行 build-servers.ps1。首次启动各服务端会生成 server_identity.key（服务器身份私钥，请备份、勿外传）。
